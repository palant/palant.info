chrome.runtime.onMessage.addListener((request, sender, sendResponse) =>
{
  if (request.type == "check_price")
  {
    $.get(request.url).done(data =>
    {
      sendResponse(data.price);
    });
    return true;
  }
});