let frame = document.createElement("iframe");
frame.style.borderWidth = "0";
frame.style.width = "100%";
frame.style.height = "100px";
document.body.appendChild(frame);

chrome.storage.local.get("message", result =>
{
  frame.src = chrome.runtime.getURL("message.html") +
    "?message=" + encodeURIComponent(result.message) +
    "&url=https://example.net/explanation";
});