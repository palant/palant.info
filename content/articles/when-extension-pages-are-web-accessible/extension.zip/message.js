$(() =>
{
  let params = new URLSearchParams(location.search);
  $(document.body).append(params.get("message") + " <button>Explain</button>");
  $("body > button").click(() =>
  {
    chrome.tabs.create({ url: params.get("url") });
  });
});
