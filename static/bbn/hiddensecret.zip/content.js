const wellHiddenSecret = "[flag]only accessible to https://mycompany.invalid[/flag]";

function isValidOrigin(origin)
{
  if (!origin)
    return false;

  if (origin === "https://mycompany.invalid")
    return true;

  if ("undefined" !== typeof gAdditionalOrigin && /^\w+:\/\/[^\/]+/.exec(gAdditionalOrigin)[0] === event.origin)
    return true;

  return false;
}

window.addEventListener("message", event =>
{
  if (!isValidOrigin(event.origin))
    return;

  if (event.data == "getsecret")
    event.source.postMessage(wellHiddenSecret, event.origin);
});
