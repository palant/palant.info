if (window.name == "%FRAME_NAME%")
{
  document.documentElement.innerHTML = `
    <html>
      <head>
        <meta charset="utf-8">
        <title>Page overlay</title>
        <style>
          body
          {
            background-color: #C0C0C0;
          }

          body, button
          {
            font-family: Sans-Serif;
            font-size: 20px;
          }

          #content
          {
            width: 400px;
            margin: auto;
            margin-top: 100px;
            border: 1px solid black;
            border-radius: 10px;
            padding: 10px;
            background-color: #FFFFFF;
            color: #000000;
          }
        </style>
      </head>
      <body>
        <div id="content">
          <h1>Make a screenshot</h1>

          <p>Please select a format for the screenshot:</p>
          <p>
            <label><input type="radio" id="png" name="format" checked> PNG</label>
          </p>
          <p>
            <label><input type="radio" id="jpeg" name="format"> JPEG</label>
          </p>

          <p>
            <button id="do_screenshot">Screenshot to clipboard</button>
          </p>
        </div>
      </body>
    </html>`;

  document.getElementById("do_screenshot").addEventListener("click", event =>
  {
    chrome.runtime.sendMessage({
      type: "captureTab",
      param: document.getElementById("png").checked ? "png" : "jpeg"
    });
  });
}
