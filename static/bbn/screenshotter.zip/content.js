let screenshotFrame = null;

function createScreenshotFrame()
{
  if (screenshotFrame)
    return;

  // Load a third-party URL into our frame so that the page cannot access it.
  // Background page will inject a content script to mess with it.
  let frame = document.createElement("iframe");
  let name = [1,2,3,4,5,6].map(_ => Math.floor(Math.random() * 36).toString(36)).join("");
  frame.src = "https://example.com/";
  frame.name = name;
  frame.style.borderWidth = "0";
  frame.style.position = "fixed";
  frame.style.left = frame.style.top = "0";
  frame.style.width = frame.style.height = "100%";
  frame.style.zIndex = "1000000";
  frame.onload = () =>
  {
    chrome.runtime.sendMessage({
      type: "initScreenshotOverlay",
      param: name
    });
  };
  document.body.appendChild(frame);

  screenshotFrame = frame;
}

function removeScreenshotFrame()
{
  if (!screenshotFrame)
    return;

  screenshotFrame.parentNode.removeChild(screenshotFrame);
  screenshotFrame = null;
}

// Allow triggering screenshot by key combination
window.addEventListener("keydown", event =>
{
  if (event.key == "S" && event.ctrlKey && event.shiftKey)
  {
    event.preventDefault();
    createScreenshotFrame();
  }
});

chrome.runtime.onMessage.addListener(message =>
{
  if (message.type == "createScreenshotFrame")
    createScreenshotFrame();
  else if (message.type == "removeScreenshotFrame")
    removeScreenshotFrame();
});
