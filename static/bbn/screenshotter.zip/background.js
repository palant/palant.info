function initScreenshotOverlay(frameName, tabId, windowId)
{
  fetch("screenshotOverlay.js").then(data => data.text()).then(text =>
  {
    let code = text.replace(/%FRAME_NAME%/g, frameName);
    chrome.tabs.executeScript(tabId, {
      code,
      allFrames: true
    });
  });
}

function captureTab(format, tabId, windowId)
{
  chrome.tabs.sendMessage(tabId, {
    type: "removeScreenshotFrame"
  }, () =>
  {
    chrome.tabs.captureVisibleTab(windowId, {
      format
    }, dataUri =>
    {
      // Firefox doesn't allow clipboard operations from the background page,
      // delegate copying to the tab itself.
      chrome.tabs.executeScript(tabId, {
        code: `
          (function()
          {
            let textarea = document.createElement("textarea");
            textarea.value = "${dataUri}";
            document.body.appendChild(textarea);
            textarea.select();
            document.execCommand("copy");
            document.body.removeChild(textarea);
          })();
        `
      });
    });
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) =>
{
  window[message.type](message.param, sender.tab.id, sender.tab.windowId);
});

chrome.browserAction.onClicked.addListener(() =>
{
  chrome.tabs.query({active: true}, tabs =>
  {
    chrome.tabs.sendMessage(tabs[0].id, {
      type: "createScreenshotFrame"
    });
  });
});
