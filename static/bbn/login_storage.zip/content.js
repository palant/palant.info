let $login = $("#login, #username");

if ($login.length == 1 && $login[0].localName == "input" && $login[0].form)
{
  chrome.runtime.sendMessage({
    type: "getLogins",
    params: [window.location.hostname]
  }, logins =>
  {
    if (!logins)
      logins = [];

    if (logins.length)
    {
      logins.sort();

      let html = `
        <div id="logins-container">
          <p>Your previous logins, choose one:</p>
          <ul>
      `;

      for (let login of logins)
        html += `<li><a href="#" data-value="${login}">${login}</a></li>`;

      html += `
          </ul>
        </div>
      `;

      $container = $(html);
      $container.click(event =>
      {
        event.preventDefault();
        let value = $(event.target).data("value");
        if (value)
          $login.val(value);
      });
      $login.parent().prepend($container);
    }

    $form = $($login[0].form);
    $form.submit(event =>
    {
      let value = $login.val().trim();
      if (value && logins.indexOf(value) < 0)
      {
        chrome.runtime.sendMessage({
          type: "addLogin",
          params: [window.location.hostname, value]
        });
      }
    });
  });
}
