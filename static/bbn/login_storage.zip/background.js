var FLAG = "Ha, this is so safe right here!";

function getLogins(host)
{
  if (host in localStorage)
    return JSON.parse(localStorage[host]);
  else
    return [];
}

function addLogin(host, login)
{
  localStorage[host] = JSON.stringify(getLogins(host).concat([login]));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) =>
{
  sendResponse(window[message.type].apply(window, message.params));
});
